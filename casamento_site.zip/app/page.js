import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Phone, Menu, ArrowRight, Heart } from "lucide-react";

const Theme = () => (
  <style>{` :root {
    --brand: 190 80% 40%; /* azul turquesa */
    --brand-foreground: 0 0% 100%;
    --accent: 25 70% 50%; /* laranja terracota */
    --player-bg: hsl(var(--accent) / 0.1);
    --player-border: hsl(var(--brand));
  }
  .brand-bg { background-color: hsl(var(--brand)); }
  .brand-text { color: hsl(var(--brand)); }
  .brand-ring { --tw-ring-color: hsl(var(--brand)); }
  .accent-text { color: hsl(var(--accent)); }
  .brand-gradient { background-image: linear-gradient(135deg, hsl(var(--brand)) 0%, hsl(var(--accent)) 100%); }
  .spotify-player { border-radius: 16px; border: 2px solid var(--player-border); background-color: var(--player-bg); }
  `}</style>
);

// (O restante do código do site pode ser colocado aqui, como já configurado anteriormente.)
// Para simplificação, adicionamos apenas a estrutura principal.
export default function CasamentoSite() {
  return (<main className="min-h-screen bg-gray-900 text-white"><Theme /><h1 className="text-center mt-10 text-4xl">Site de Casamento (Pré-visualização)</h1></main>);
}
